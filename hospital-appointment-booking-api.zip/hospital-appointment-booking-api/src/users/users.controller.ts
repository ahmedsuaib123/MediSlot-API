import {Body,Controller,Post,Get,Patch,Delete,Param,ParseIntPipe,Query,Req,DefaultValuePipe} from '@nestjs/common';

import type { Request } from 'express';

import { UsersService } from './users.service.js';

import { CreateUserDto } from './dtos/create-user.dto.js';
import { UpdateUserDto } from './dtos/update-user.dto.js';

import { UserRole } from './entities/users.entity.js';

import { Roles } from '../auth/roles/roles.decorator.js';

@Controller('users')
export class UsersController {

  constructor(
    private readonly usersService: UsersService,
  ) {}


  // CREATE USER
  @Roles(UserRole.ADMIN)
  @Post()
  async createUser(
    @Body() user: CreateUserDto,
  ) {
    return this.usersService.createUser(user);
  }


  // GET ALL USERS WITH PAGINATION
  @Roles(UserRole.ADMIN)
  @Get()
  async getAllUsers(
    @Query('page', new DefaultValuePipe(1), ParseIntPipe)
    page: number,

    @Query('limit', new DefaultValuePipe(10), ParseIntPipe)
    limit: number,

    @Query('role')
    role?: UserRole,
  ) {
    return this.usersService.getAllUsers(
      page,
      limit,
      role,
    );
  }


  // GET USER BY ID
  @Roles(UserRole.ADMIN)
  @Get(':id')
  async getUserById(
    @Param('id', ParseIntPipe) id: number,
  ) {
    return this.usersService.getUserById(id);
  }


  // UPDATE USER
  @Patch(':id')
  async updateUser(
    @Param('id', ParseIntPipe) id: number,

    @Body() updateData: UpdateUserDto,

    @Req() req: Request,
  ) {

    const requester = req.user as {
      id: number;
      role: UserRole;
    };

    return this.usersService.updateUser(
      id,
      updateData,
      requester.id,
      requester.role,
    );
  }


  // DEACTIVATE USER
  @Roles(UserRole.ADMIN)
  @Delete(':id')
  async deactivateUser(
    @Param('id', ParseIntPipe) id: number,

    @Req() req: Request,
  ) {

    const requester = req.user as {
      id: number;
      role: UserRole;
    };

    return this.usersService.deactivateUser(
      id,
      requester.role,
    );
  }
}
