import {Injectable,ConflictException,NotFoundException,BadRequestException,ForbiddenException} from '@nestjs/common';

import { InjectRepository } from '@nestjs/typeorm';
import { Repository, DataSource } from 'typeorm';

import { Users, UserRole } from './entities/users.entity.js';
import { Doctors } from '../doctors/entities/doctors.entity.js';

import { CreateUserDto } from './dtos/create-user.dto.js';
import { UpdateUserDto } from './dtos/update-user.dto.js';

import * as bcrypt from 'bcrypt';

@Injectable()
export class UsersService {

  constructor(
    @InjectRepository(Users)
    private readonly userRepo: Repository<Users>,

    @InjectRepository(Doctors)
    private readonly doctorRepo: Repository<Doctors>,

    private readonly dataSource: DataSource,
  ) {}

  // CREATE USER
  // If role is DOCTOR, create Doctor profile automatically.

  async createUser(user: CreateUserDto) {

    try {

      const result = await this.dataSource.transaction(
        async (manager) => {

          const existingUser = await manager.findOne(Users, {
            where: { email: user.email },
          });

          if (existingUser) {
            throw new ConflictException(
              'Email Already Registered',
            );
          }

          const hashedPassword = await bcrypt.hash(
            user.password,
            10,
          );

          const newUser = manager.create(Users, {
            fullname: user.fullname,
            email: user.email,
            contact: user.contact,
            age: user.age,
            gender: user.gender,
            bloodgroup: user.bloodgroup,
            password_hash: hashedPassword,
            role: user.role,
            isActive: true,
          });

          const savedUser = await manager.save(
            Users,
            newUser,
          );

          let savedDoctor: Doctors | null = null;

          if (user.role === UserRole.DOCTOR) {

            const doctor = manager.create(Doctors, {
              specialization: user.specialization!,
              consultationFee: user.consultationFee!,
              experienceYear: user.experienceYear!,
              user: savedUser,
            });

            savedDoctor = await manager.save(
              Doctors,
              doctor,
            );
          }

          return {
            user: {
              userid: savedUser.userid,
              fullname: savedUser.fullname,
              email: savedUser.email,
              contact: savedUser.contact,
              role: savedUser.role,
            },

            doctor: savedDoctor
              ? {
                  doctorid: savedDoctor.doctorid,
                  specialization: savedDoctor.specialization,
                  consultationFee: savedDoctor.consultationFee,
                  experienceYear: savedDoctor.experienceYear,
                }
              : null,
          };
        },
      );

      return {
        message: 'User Created Successfully',
        data: result,
      };

    } catch (error) {

      if (
        error instanceof ConflictException ||
        error instanceof BadRequestException
      ) {
        throw error;
      }

      console.error('USER REGISTRATION ERROR:', error);

      throw new BadRequestException(
        'User Creation Failed',
      );
    }
  }


  // GET ALL USERS WITH PAGINATION

  async getAllUsers(page = 1, limit = 10, role?: UserRole) {

    const skip = (page - 1) * limit;

    const query = this.userRepo
      .createQueryBuilder('user')
      .select([
        'user.userid',
        'user.fullname',
        'user.email',
        'user.contact',
        'user.age',
        'user.gender',
        'user.bloodgroup',
        'user.role',
        'user.isActive',
        'user.created_at',
      ]);

    if (role) {
      query.andWhere('user.role = :role', { role });
    }

    const [users, total] = await query
      .orderBy('user.userid', 'DESC')
      .skip(skip)
      .take(limit)
      .getManyAndCount();

    return {
      message: 'Users Retrieved Successfully',
      data: users,
      meta: {
        total,
        page,
        limit,
        totalPages: Math.ceil(total / limit),
      },
    };
  }


  // GET USER BY ID
  async getUserById(id: number): Promise<Users> {

    const user = await this.userRepo.findOne({
      where: { userid: id },
      select: {
        userid: true,
        fullname: true,
        email: true,
        contact: true,
        age: true,
        gender: true,
        bloodgroup: true,
        role: true,
        isActive: true,
        created_at: true,
        updated_at: true,
      },
    });

    if (!user) {
      throw new NotFoundException('User Not Found');
    }

    return user;
  }


  // UPDATE USER
  async updateUser(
    id: number,
    updateData: UpdateUserDto,
    requesterId: number,
    requesterRole: UserRole,
  ) {

        const user = await this.userRepo.findOne({
        where: { 
            userid: id 
        },
        });

    if (!user) {
      throw new NotFoundException('User Not Found');
    }

    const isAdmin = requesterRole === UserRole.ADMIN;
    const isOwner = requesterId === id;

    if (!isAdmin && !isOwner) {
      throw new ForbiddenException(
        'You cannot update this user',
      );
    }

    if (!isAdmin && updateData.isActive !== undefined) {
      throw new ForbiddenException(
        'Only Admin can change account status',
      );
    }

    if (updateData.fullname !== undefined) {
      user.fullname = updateData.fullname;
    }

    if (updateData.contact !== undefined) {
      user.contact = updateData.contact;
    }

    if (isAdmin && updateData.isActive !== undefined) {
      user.isActive = updateData.isActive;
    }

    const updatedUser = await this.userRepo.save(user);

    return {
      message: 'User Updated Successfully',
      data: {
        userid: updatedUser.userid,
        fullname: updatedUser.fullname,
        email: updatedUser.email,
        contact: updatedUser.contact,
        role: updatedUser.role,
        isActive: updatedUser.isActive,
      },
    };
  }


  // SOFT DELETE USER

  async deactivateUser(
    id: number,
    requesterRole: UserRole,
  ) {

    if (requesterRole !== UserRole.ADMIN) {
      throw new ForbiddenException(
        'Only Admin can deactivate users',
      );
    }

    const user = await this.userRepo.findOne({
      where: { userid: id },
    });

    if (!user) {
      throw new NotFoundException('User Not Found');
    }

    if (!user.isActive) {
      throw new BadRequestException(
        'User is already inactive',
      );
    }

    user.isActive = false;

    await this.userRepo.save(user);

    return {
      message: 'User Deactivated Successfully',
      userid: user.userid,
      isActive: user.isActive,
    };
  }
}
